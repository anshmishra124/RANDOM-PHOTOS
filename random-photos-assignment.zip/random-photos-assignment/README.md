# Random Photos - Frontend Beginner Assignment 7

This project displays a grid of six random images using [Picsum Photos](https://picsum.photos). The images are randomly generated every time the page loads, and a "Load New Images" button is provided to refresh the images manually.

## Features

- Responsive image grid
- Six random images from the internet
- Refresh images using a button

## How to Use

1. Open `index.html` in your browser.
2. View the 6 random images.
3. Click the **Load New Images** button to generate a new set of images.

---
**Assignment by Bridge Engineers | Beginner Frontend Level**